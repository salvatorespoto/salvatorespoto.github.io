---
author: Hugo Authors
title: Using OpenStreetMap
date: 2022-02-14
description: Using Map functionality within this theme using openstreetmap
---

{{<openstreetmap mapName="demo-map_1" scale="14" coordX="-37.7989" coordY="145.0003">}}